﻿namespace VendingMachineApplication
{
    enum Products
    {
        Coke = 1,
        Chips = 2,
        Candy = 3
    }
}
