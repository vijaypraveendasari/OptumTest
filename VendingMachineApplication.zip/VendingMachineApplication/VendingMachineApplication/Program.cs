﻿using System;

namespace VendingMachineApplication
{
    class Program
    {
        static void Main(string[] args)
        {
            try
            {
                Console.WriteLine("Welcome to Vending Machine");
                Console.WriteLine("Please select item from below list: ");
                Console.WriteLine("1: Coke ($1.0)");
                Console.WriteLine("2: Chips ($0.50)");
                Console.WriteLine("3: Candy ($0.65)");

                int item = 0;
                var itemSelection = Console.ReadLine();
                if (!int.TryParse(itemSelection, out item))
                {
                    Console.WriteLine("Invalid Selection");
                    return;
                }

                var itemCost = GetPriceByItem(item);
                if (itemCost == 0)
                {
                    Console.WriteLine("Invalid item Selected.Please try again!! Thank you");
                    return;
                }

                double totalAmount = 0;
                while (true)
                {
                    if (totalAmount >= itemCost)
                        break;

                    Console.WriteLine("Please select Y to Add Money");
                    var input = Console.ReadLine();
                    if (input.ToUpper() != "Y")
                        break;

                    Console.WriteLine("Please select the coin type that you are inserting from below options");
                    Console.WriteLine("1: Nickle");
                    Console.WriteLine("2: Dimes");
                    Console.WriteLine("3: Quarters");
                    Console.WriteLine("4: Pennies");

                    int coinType;
                    var selection = Console.ReadLine();
                    if (!int.TryParse(selection, out coinType))
                    {
                        Console.WriteLine("Invalid Selection! Please try again");
                        continue;
                    }

                    var price = GetUnitvalueByCoin(coinType);
                    if (price == 0)
                    {
                        Console.WriteLine("Invalid Coin Selected.Please try again");
                        continue;
                    }
                    totalAmount += price;
                }

                if (totalAmount < itemCost)
                {
                    if (totalAmount == 0)
                        return;
                    Console.WriteLine("Unable to Complete Purchase");
                    var difference = totalAmount - itemCost;
                    Console.WriteLine("Please take difference amount of " + difference);
                    return;
                }

                Console.WriteLine("Thanks for the purchase");

                if (totalAmount > itemCost)
                {
                    var difference = itemCost - totalAmount;
                    Console.WriteLine("Please take difference amount of " + difference);
                }
                totalAmount = 0;

                Console.WriteLine("Thank you");


            }
            catch (Exception ex)
            {
                Console.WriteLine("Exception Caught with details " + ex.Message);
            }

            Console.ReadKey();
        }

        private static double GetPriceByItem(int item)
        {
            if (item == (int)Products.Coke)
                return 1.00;
            if (item == (int)Products.Chips)
                return 0.50;
            if (item == (int)Products.Candy)
                return 0.65;
            return 0;
        }

        private static double GetUnitvalueByCoin(int coinType)
        {
            if (coinType == (int)Coins.Nickle)
                return 0.05;
            if (coinType == (int)Coins.Dimes)
                return 0.05;
            if (coinType == (int)Coins.Quarters)
                return 0.5;
            return 0;
        }
    }
}
