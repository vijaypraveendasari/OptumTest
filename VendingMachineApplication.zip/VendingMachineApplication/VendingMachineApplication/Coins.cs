﻿namespace VendingMachineApplication
{
    enum Coins
    {
        Nickle = 1,
        Dimes = 2,
        Quarters = 3
    }
}
